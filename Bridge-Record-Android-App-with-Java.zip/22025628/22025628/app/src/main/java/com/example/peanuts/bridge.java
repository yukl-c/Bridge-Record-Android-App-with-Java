package com.example.peanuts;

public class bridge {

    private String bridgeName;
    private String inspectionDate;
    private int statusIndex;
    private String location;

    final public static String[] status = {"Null", "Good", "Moderate", "Poor"};

    public bridge(String bridgeName, String inspectionDate,  int statusIndex, String location) {
        this.bridgeName = bridgeName;
        this.inspectionDate = inspectionDate;
        this.statusIndex = statusIndex;
        this.location = location;
    }

    public void setBridgeName(String bridgeName) {
        this.bridgeName = bridgeName;
    }

    public void setInspectionDate(String name) {
        this.inspectionDate = inspectionDate;
    }

    public void setUnitIndex(int unitIndex) {
        this.statusIndex = statusIndex;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getBridgeName() {
        return bridgeName;
    }

    public String getInspectionDate() {
        return inspectionDate;
    }

    public int getStatusIndex() {
        return statusIndex;
    }

    public String getLocation() {
        return location;
    }

    public String toString() {
        return bridgeName + " is " + status[statusIndex] + " on " + inspectionDate + " at " + location;
    }
}
