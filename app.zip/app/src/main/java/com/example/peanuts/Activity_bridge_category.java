package com.example.peanuts;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.LinkedList;

public class Activity_bridge_category extends AppCompatActivity {

    public static LinkedList<bridge> bridgeList = new LinkedList<>();

    ListView listView;
    ArrayAdapter<bridge> adapter;

    TextView textView_BridgeCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_bridge_category);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_bridge_category);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        listView = (ListView) findViewById(R.id.listView_bridge_category_options);
        textView_BridgeCount = (TextView) findViewById(R.id.textView_BridgeCount);

        AdapterView.OnItemClickListener itemClickListener =
                new AdapterView.OnItemClickListener(){
                    @Override
                    public void onItemClick(AdapterView<?> listView,
                                            View itemView,
                                            int position,
                                            long id) {
                        Intent intent = new Intent(Activity_bridge_category.this, Activity_add.class);
                        intent.putExtra("item_index", id);
                        startActivity(intent);
                    }
                };
        listView.setOnItemClickListener(itemClickListener);

        AdapterView.OnItemLongClickListener itemLongClickListener =
                new AdapterView.OnItemLongClickListener(){
                    @Override
                    public boolean onItemLongClick(AdapterView<?> listView,
                                                   View itemView,
                                                   int position,
                                                   final long id) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(Activity_bridge_category.this);

                        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int button_id) {
                                bridgeList.remove((int)id);
                                refreshList();
                                Toast.makeText(getApplicationContext(), "Bridge record deleted", Toast.LENGTH_SHORT).show();
                            }
                        });
                        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int button_id) {
                                Toast.makeText(getApplicationContext(), "Cancelled", Toast.LENGTH_SHORT).show();
                            }
                        });

                        builder.setTitle("Warning");
                        builder.setMessage("Are you sure you want to delete record " + id + "?");

                        AlertDialog dialog = builder.create();
                        dialog.show();

                        return true;
                    }
                };
        listView.setOnItemLongClickListener(itemLongClickListener);
    }

    public void refreshList() {
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, bridgeList);
        listView.setAdapter(adapter);

        Long numCount = new Long(bridgeList.size());

        if (numCount == 0) {
            textView_BridgeCount.setText("None of the inspected bridge");
        } else {
            textView_BridgeCount.setText("Inspected bridge in the list: " + numCount.toString());
        }

    }

    @Override
    public void onStart() {
        super.onStart();
        refreshList();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.new_item:
                startActivity(new Intent(this, Activity_add.class));
                return true;
            //Task 2 in Practical 7
            case R.id.delete_all:
                AlertDialog.Builder builder = new AlertDialog.Builder(this);

                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        bridgeList.clear();
                        refreshList();
                        Toast.makeText(getApplicationContext(), "Bridge repair record list cleared", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        Toast.makeText(getApplicationContext(), "Cancelled", Toast.LENGTH_SHORT).show();
                    }
                });

                builder.setTitle("Warning");
                builder.setMessage("This will clear the Bridge repair list!");

                // Create the AlertDialog
                AlertDialog dialog = builder.create();

                dialog.show();

                return true;
            case R.id.help_main:
                Dialog help_dialog = new Dialog(this);
                help_dialog.setContentView(R.layout.layout_help_main);
                help_dialog.show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}
