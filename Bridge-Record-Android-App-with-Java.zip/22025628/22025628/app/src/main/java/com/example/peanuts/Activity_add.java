package com.example.peanuts;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.Calendar;

public class Activity_add extends AppCompatActivity {

    EditText editBridge_name;
    TextView editInspection_date;
    Spinner spinner_unit;
    TextView editLocation;


    String locationText;


    boolean newBridgeRecord;
    long BridgeRecord_index;

    LocationManager locationManager;
    LocationListener locationListener = new MyLocationListener();

    Button buttonInspectionDate;

    Boolean allFieldsCorrect = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_add);

        //location
        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);  // Create the location manager.

        try {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 1, locationListener);
        } catch (SecurityException e) {
            System.out.println(e.toString());
        }

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_item);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        editBridge_name = (EditText)findViewById(R.id.editText_name);
        editInspection_date = (TextView)findViewById(R.id.editInspection_date);
        spinner_unit = (Spinner) findViewById(R.id.spinner_unit);
        editLocation = (TextView) findViewById(R.id.editLocation);

        //inspection date button
        buttonInspectionDate = (Button) findViewById(R.id.buttonInspectionDate);

        buttonInspectionDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();

                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int day = c.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        Activity_add.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {
                                editInspection_date.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);
                            }
                        },year, month, day);
                datePickerDialog.show();
            }
        });



        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, bridge.status);
        spinner_unit.setAdapter(adapter);

        Intent intent = getIntent();
        BridgeRecord_index = intent.getLongExtra("item_index", -1);

        if(BridgeRecord_index == -1) {
            newBridgeRecord = true;
        } else {
            editBridge_name.setText(Activity_bridge_category.bridgeList.get((int)BridgeRecord_index).getBridgeName());
            editInspection_date.setText(Activity_bridge_category.bridgeList.get((int)BridgeRecord_index).getInspectionDate());
            spinner_unit.setSelection(Activity_bridge_category.bridgeList.get((int)BridgeRecord_index).getStatusIndex());
            editLocation.setText(Activity_bridge_category.bridgeList.get((int)BridgeRecord_index).getLocation());
            newBridgeRecord = false;
        }


    }

    public class MyLocationListener implements LocationListener {

        @Override
        public void onLocationChanged(Location location) {
            locationText = "( " + location.getLatitude() + " , " + location.getLongitude() + " )";
            //editLocation.setText(locationText);
        }

        public void onStatusChanged(String provider, int status, Bundle extras) {}

        public void onProviderEnabled(String provider) {}

        public void onProviderDisabled(String provider) {}
    }

    public void onClickLocation(View view) {
        editLocation.setText(locationText);
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_item, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {


            case R.id.save_item:
                String stringBridge_name = editBridge_name.getText().toString();
                String stringInspection_date = editInspection_date.getText().toString();
                int intSpinner_unit = (int)spinner_unit.getSelectedItemId();
                String stringLocation =  editLocation.getText().toString();

                if ((stringBridge_name.split(" ")).length < 2) {
                    CharSequence text = "invalid name";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(this, text, duration);
                    toast.show();
                    return false;
                } else if (stringInspection_date.length() == 0) {
                    CharSequence text = "invalid inspection date";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(this, text, duration);
                    toast.show();
                    return false;
                } else if (intSpinner_unit == 0) {
                    CharSequence text = "invalid status";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(this, text, duration);
                    toast.show();
                    return false;
                } else if (stringLocation.length() == 0) {
                    CharSequence text = "invalid location";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(this, text, duration);
                    toast.show();
                    return false;
                } else {
                    if(newBridgeRecord) {
                        Activity_bridge_category.bridgeList.add(new bridge(
                                stringBridge_name,
                                stringInspection_date,
                                intSpinner_unit,
                                stringLocation));
                    } else {
                        Activity_bridge_category.bridgeList.set((int)BridgeRecord_index, new bridge(
                                stringBridge_name,
                                stringInspection_date,
                                intSpinner_unit,
                                stringLocation));
                    }
                    finish();
                    return true;
                }


            case R.id.delete_item:
                AlertDialog.Builder builder = new AlertDialog.Builder(this);


                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        Activity_bridge_category.bridgeList.remove((int)BridgeRecord_index);
                        Toast.makeText(getApplicationContext(), "bridge repair record deleted", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        Toast.makeText(getApplicationContext(), "Cancelled", Toast.LENGTH_SHORT).show();
                    }
                });

                builder.setTitle("Warning");
                builder.setMessage("Are you sure you want to delete the bridge repair record?");

                AlertDialog dialog = builder.create();

                dialog.show();
                return true;

            case R.id.help_item:
                Dialog help_dialog = new Dialog(this);
                TextView helpText = new TextView(this);

                help_dialog.setContentView(R.layout.layout_help_add);
                help_dialog.show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
